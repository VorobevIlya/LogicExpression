import Foundation

extension Int {
    public static var binaryBase: Int { return 2 }
    public func toThePower(_ power: Int) -> Int {
        return Int(pow(Double(self), Double(power)))
    }
}
