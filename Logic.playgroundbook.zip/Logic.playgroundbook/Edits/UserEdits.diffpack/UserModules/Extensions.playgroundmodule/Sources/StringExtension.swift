
extension String {
    public init(_ number: Int, radix: Int, minLength: Int) {
        var str = Self(number, radix: radix)
        if minLength > str.count {
            str = Self(repeating: "0", count: minLength - str.count) + str
        }
        self = str
    }
}
