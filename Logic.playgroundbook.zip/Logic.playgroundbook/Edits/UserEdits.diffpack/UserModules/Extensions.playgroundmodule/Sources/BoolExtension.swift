
extension Bool {
    public func binaryCoded() -> String {
        return self ? "1" : "0"
    }
}
