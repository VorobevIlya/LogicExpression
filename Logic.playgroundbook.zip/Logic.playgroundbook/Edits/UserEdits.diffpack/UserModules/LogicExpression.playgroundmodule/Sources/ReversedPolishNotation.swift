
import DataStructures

public struct ReversedPolishNotation {
    public static let priorities: [Character: Int] = ["-": 1, "*": 2, "+": 3, "^": 4, ">": 5, "=": 6]
    
    public static func evaluate(_ input: String, for values: [Character: Bool]) -> Bool {
        var output = Stack<Bool>()
        for element in input {
            switch element {
            case "-":
                let value = output.pop()!
                output.push(!value)
            case "*":
                let rhs = output.pop()!
                let lhs = output.pop()!
                output.push(lhs && rhs)
            case "+":
                let rhs = output.pop()!
                let lhs = output.pop()!
                output.push(lhs || rhs)
            case "^":
                let rhs = output.pop()!
                let lhs = output.pop()!
                output.push(lhs != rhs)
            case ">":
                let rhs = output.pop()!
                let lhs = output.pop()!
                output.push(!lhs || rhs)
            case "=":
                let rhs = output.pop()!
                let lhs = output.pop()!
                output.push(lhs == rhs)
            default:
                output.push(values[element]!)
            }
        }
        return output.peek()!
    }
    
    public static func evaluate(_ input: String, forAll arguments: Set<Character>) -> [Bool] {
        var table: [Bool] = []
        for i in 0 ..< Int.binaryBase.toThePower(arguments.count) {
            var binaryString = String(i, radix: 2, minLength: arguments.count)
            let booleanValues = binaryString.map({ return $0 == "1" })
            let argsCombination = Dictionary(uniqueKeysWithValues: zip(arguments.sorted(), booleanValues))
            table.append(Self.evaluate(input, for: argsCombination))
        }
        return table
    }
    
    public static func translate(_ string: String) -> (expression: String, arguments: Set<Character>)? {
        if string.isEmpty { return nil }
        var preparedString = string.filter({ $0 != " " })
        var output = ""
        var arguments = Set<Character>()
        var input = Array<Character>(preparedString)
        input.reverse()
        var stack = Stack<Character>()
        while !input.isEmpty {
            let next = input.removeLast()
            switch next {
            case "(":
                stack.push(next) 
            case ")":
                while stack.peek() != "(" {
                    output.append(stack.pop()!)
                }
                stack.pop()
            case "-", "*", "+", "^", ">", "=":
                while true {
                    guard let top = stack.peek() else { break }
                    guard top != "(" else { break }
                    guard priorities[top]! < priorities[next]! else { break }
                    output.append(stack.pop()!)
                }
                stack.push(next)
            default:
                output.append(next)
                arguments.update(with: next)
            }
        }
        while !stack.isEmpty {
            output.append(stack.pop()!)
        }
        if arguments.isEmpty { return nil }
        return (output, arguments)
    }
}

