import DataStructures
import Extensions

public struct LogicExpression {
    
    public let directNotation: String
    public let arguments: Set<Character>
    public let reversedNotation: String
    public let truthTable: [Bool]
    
    public var isIdenticallyTrue: Bool {
        return !truthTable.contains(false)
    }
    
    public var isIdenticallyFalse: Bool {
        return !truthTable.contains(true)
    }
    
    public init?(directNotation: String) {
        if directNotation.isEmpty { return nil }
        self.directNotation = directNotation
        guard let (exp, args) = ReversedPolishNotation.translate(directNotation) else { return nil }
        arguments = args
        reversedNotation = exp
        truthTable = ReversedPolishNotation.evaluate(exp, forAll: args)
    }
    
    public func printTruthTable() {
        guard !truthTable.isEmpty else {
            print("Truth table is empty")
            return
        }
        print(arguments.map({ String($0) }).sorted().joined(separator: " "))
        for (index, value) in truthTable.enumerated() {
            print(String(index, radix: 2, minLength: arguments.count).map({ String($0) }).joined(separator: " "), value.binaryCoded())
        }
    }
}
